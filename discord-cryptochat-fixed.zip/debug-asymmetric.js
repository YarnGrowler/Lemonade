/**
 * Debug script for testing asymmetric encryption
 * Run in Discord console to test the asymmetric system
 */

window.debugAsymmetric = {
  
  // Check system status
  checkStatus() {
    console.log('🔐 [DEBUG] === ASYMMETRIC SYSTEM STATUS ===');
    console.log('🔐 [DEBUG] Main extension available:', !!window.discordCryptochat);
    console.log('🔐 [DEBUG] ECCrypto available:', !!window.ecCrypto);
    console.log('🔐 [DEBUG] ECMessageProcessor available:', !!window.ecMessageProcessor);
    console.log('🔐 [DEBUG] AsymmetricContentIntegration class available:', !!window.AsymmetricContentIntegration);
    
    if (window.discordCryptochat) {
      console.log('🔐 [DEBUG] Main extension asymmetric object:', !!window.discordCryptochat.asymmetric);
      console.log('🔐 [DEBUG] encryptAsymmetricMessage method:', typeof window.discordCryptochat.encryptAsymmetricMessage);
      console.log('🔐 [DEBUG] processAsymmetricMessage method:', typeof window.discordCryptochat.processAsymmetricMessage);
      
      if (window.discordCryptochat.asymmetric) {
        const status = window.discordCryptochat.asymmetric.getStatus();
        console.log('🔐 [DEBUG] Asymmetric status:', status);
      }
    }
    
    if (window.ecCrypto) {
      const ecStatus = window.ecCrypto.getStatus();
      console.log('🔐 [DEBUG] ECCrypto status:', ecStatus);
      
      const userList = window.ecCrypto.getUserList();
      console.log('🔐 [DEBUG] Known users:', userList);
    }
    
    console.log('🔐 [DEBUG] =============================');
  },
  
  // Force reinitialize asymmetric system
  async reinitialize() {
    console.log('🔐 [DEBUG] 🔄 Force reinitializing asymmetric system...');
    
    if (window.discordCryptochat && typeof window.discordCryptochat.initAsymmetricEncryption === 'function') {
      await window.discordCryptochat.initAsymmetricEncryption();
      
      // Check status after 3 seconds
      setTimeout(() => {
        this.checkStatus();
      }, 3000);
    } else {
      console.log('🔐 [DEBUG] ❌ Main extension not available');
    }
  },
  
  // Test encryption/decryption
  async testEncryption() {
    console.log('🔐 [DEBUG] 🧪 Testing asymmetric encryption...');
    
    if (!window.discordCryptochat || !window.discordCryptochat.asymmetric) {
      console.log('🔐 [DEBUG] ❌ Asymmetric system not available');
      return;
    }
    
    const testMessage = "Hello asymmetric world! " + Date.now();
    console.log('🔐 [DEBUG] 📝 Test message:', testMessage);
    
    try {
      // Test encryption
      const encryptResult = await window.discordCryptochat.encryptAsymmetricMessage(testMessage);
      console.log('🔐 [DEBUG] 📤 Encrypt result:', encryptResult);
      
      if (encryptResult.success) {
        console.log('🔐 [DEBUG] ✅ Encryption successful!');
        console.log('🔐 [DEBUG] 📦 Encrypted text length:', encryptResult.encryptedText.length);
        
        // Test decryption
        const decryptResult = await window.discordCryptochat.processAsymmetricMessage(encryptResult.encryptedText, null);
        console.log('🔐 [DEBUG] 📨 Decrypt result:', decryptResult);
        
        if (decryptResult.success) {
          console.log('🔐 [DEBUG] ✅ Decryption successful!');
          console.log('🔐 [DEBUG] 📝 Decrypted text:', decryptResult.decryptedText);
          console.log('🔐 [DEBUG] 🎯 Match:', decryptResult.decryptedText === testMessage);
        } else {
          console.log('🔐 [DEBUG] ❌ Decryption failed:', decryptResult.error);
        }
      } else {
        console.log('🔐 [DEBUG] ❌ Encryption failed:', encryptResult.error);
      }
    } catch (error) {
      console.log('🔐 [DEBUG] ❌ Test failed:', error);
    }
  },
  
  // Quick commands
  help() {
    console.log('🔐 [DEBUG] Available commands:');
    console.log('debugAsymmetric.checkStatus() - Check system status');
    console.log('debugAsymmetric.reinitialize() - Force reinitialize');
    console.log('debugAsymmetric.testEncryption() - Test encrypt/decrypt');
    console.log('debugAsymmetric.help() - Show this help');
  }
};

// Show help on load
console.log('🔐 [DEBUG] Asymmetric debug tool loaded!');
console.log('🔐 [DEBUG] Type debugAsymmetric.help() for commands'); 