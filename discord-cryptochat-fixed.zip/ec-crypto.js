/**
 * Discord Cryptochat - Simplified Asymmetric Encryption Module
 * Uses hardcoded static key with simple user key discovery
 */

class ECCrypto {
  constructor() {
    this.algorithm = 'ECDH';
    this.curve = 'P-256';
    this.aesAlgorithm = 'AES-GCM';
    
    // Hardcoded static keypair (known to all users)
    this.staticPrivateKey = null;
    this.staticPublicKey = null;
    
    // User public keys discovered from messages: userId -> {publicKey, keyId, username, lastSeen}
    this.userKeys = new Map();
    
    console.log('🔐 [EC] Initializing simplified crypto system...');
    this.init();
  }

  async init() {
    try {
      await this.loadOrGenerateStaticKeypair();
      await this.loadUserKeys();
      console.log('🔐 [EC] ✅ Crypto system initialized');
      console.log('🔐 [EC] 📊 Loaded user keys:', this.userKeys.size);
    } catch (error) {
      console.error('🔐 [EC] ❌ Failed to initialize:', error);
    }
  }

  // ==================== HARDCODED STATIC KEY MANAGEMENT ====================

  async loadOrGenerateStaticKeypair() {
    try {
      // Try to load existing static keypair
      const stored = await chrome.storage.local.get(['ecStaticPrivateKey', 'ecStaticPublicKey']);
      
      if (stored.ecStaticPrivateKey && stored.ecStaticPublicKey) {
        this.staticPrivateKey = await this.importPrivateKey(stored.ecStaticPrivateKey);
        this.staticPublicKey = await this.importPublicKey(stored.ecStaticPublicKey);
        console.log('🔐 [EC] 🔑 Static keypair loaded from storage');
      } else {
        // Generate new static keypair
        await this.generateStaticKeypair();
      }
      
      // Log key info for debugging
      const publicKeyBase64 = await this.exportPublicKey(this.staticPublicKey);
      const keyId = this.generateKeyId(publicKeyBase64);
      console.log('🔐 [EC] 🆔 My Key ID:', keyId);
      console.log('🔐 [EC] 🔑 My Public Key:', publicKeyBase64.substring(0, 32) + '...');
      
    } catch (error) {
      console.error('🔐 [EC] ❌ Static keypair error:', error);
      throw error;
    }
  }

  async generateStaticKeypair() {
    console.log('🔐 [EC] 🔄 Generating new static keypair...');
    
    const keypair = await crypto.subtle.generateKey(
      {
        name: this.algorithm,
        namedCurve: this.curve
      },
      true,
      ['deriveKey']
    );
    
    this.staticPrivateKey = keypair.privateKey;
    this.staticPublicKey = keypair.publicKey;
    
    // Export and store
    const exportedPrivate = await this.exportPrivateKey(this.staticPrivateKey);
    const exportedPublic = await this.exportPublicKey(this.staticPublicKey);
    
    await chrome.storage.local.set({
      ecStaticPrivateKey: exportedPrivate,
      ecStaticPublicKey: exportedPublic
    });
    
    console.log('🔐 [EC] ✅ New static keypair generated and stored');
  }

  // ==================== USER KEY DISCOVERY & STORAGE ====================

  addUserKey(userId, publicKeyBase64, username = 'Unknown') {
    const keyId = this.generateKeyId(publicKeyBase64);
    const userInfo = {
      publicKey: publicKeyBase64,
      keyId: keyId,
      username: username,
      lastSeen: Date.now(),
      discoveredAt: Date.now()
    };
    
    this.userKeys.set(userId, userInfo);
    this.saveUserKeys();
    
    console.log('🔐 [EC] 👤 NEW USER DISCOVERED!');
    console.log('🔐 [EC] 🆔 User ID:', userId);
    console.log('🔐 [EC] 👤 Username:', username);
    console.log('🔐 [EC] 🔑 Key ID:', keyId);
    console.log('🔐 [EC] 📊 Total users:', this.userKeys.size);
  }

  getUserKey(userId) {
    const userInfo = this.userKeys.get(userId);
    if (userInfo) {
      console.log('🔐 [EC] 🔍 Found key for user:', userId, '- Key ID:', userInfo.keyId);
      return userInfo.publicKey;
    }
    console.log('🔐 [EC] ❌ No key found for user:', userId);
    return null;
  }

  getMostRecentUserKey() {
    if (this.userKeys.size === 0) {
      console.log('🔐 [EC] ❌ No user keys available');
      return null;
    }
    
    let mostRecent = null;
    let latestTime = 0;
    
    for (const [userId, userInfo] of this.userKeys) {
      if (userInfo.lastSeen > latestTime) {
        latestTime = userInfo.lastSeen;
        mostRecent = { userId, ...userInfo };
      }
    }
    
    if (mostRecent) {
      console.log('🔐 [EC] 🎯 Most recent user key:', mostRecent.userId, '- Key ID:', mostRecent.keyId);
    }
    
    return mostRecent;
  }

  async saveUserKeys() {
    try {
      const keysObject = Object.fromEntries(this.userKeys);
      await chrome.storage.local.set({ ecUserKeys: keysObject });
      console.log('🔐 [EC] 💾 Saved', this.userKeys.size, 'user keys');
    } catch (error) {
      console.error('🔐 [EC] ❌ Failed to save user keys:', error);
    }
  }

  async loadUserKeys() {
    try {
      const stored = await chrome.storage.local.get(['ecUserKeys']);
      if (stored.ecUserKeys) {
        this.userKeys = new Map(Object.entries(stored.ecUserKeys));
        console.log('🔐 [EC] 📂 Loaded', this.userKeys.size, 'user keys from storage');
        
        // Log all stored users
        for (const [userId, userInfo] of this.userKeys) {
          console.log('🔐 [EC] 👤 Stored user:', userId, '- Username:', userInfo.username, '- Key ID:', userInfo.keyId);
        }
      }
    } catch (error) {
      console.error('🔐 [EC] ❌ Failed to load user keys:', error);
    }
  }

  // ==================== ENCRYPTION/DECRYPTION ====================

  async encrypt(plaintext, recipientUserId = null) {
    console.log('🔐 [EC] 📤 ENCRYPTING MESSAGE...');
    console.log('🔐 [EC] 📝 Message:', plaintext);
    console.log('🔐 [EC] 🎯 Recipient:', recipientUserId || 'auto-detect');
    
    let recipientPublicKey;
    let keyUsed = 'static';
    
    // Try to use specific user's key first
    if (recipientUserId) {
      const userPublicKeyBase64 = this.getUserKey(recipientUserId);
      if (userPublicKeyBase64) {
        recipientPublicKey = await this.importPublicKey(userPublicKeyBase64);
        keyUsed = 'user_specific';
        console.log('🔐 [EC] 🔑 Using specific user key for:', recipientUserId);
      }
    }
    
    // Fallback to most recent user key
    if (!recipientPublicKey) {
      const mostRecent = this.getMostRecentUserKey();
      if (mostRecent) {
        recipientPublicKey = await this.importPublicKey(mostRecent.publicKey);
        keyUsed = 'most_recent';
        console.log('🔐 [EC] 🔑 Using most recent user key from:', mostRecent.userId);
      }
    }
    
    // Final fallback to static key
    if (!recipientPublicKey) {
      recipientPublicKey = this.staticPublicKey;
      keyUsed = 'static';
      console.log('🔐 [EC] 🔑 Using static fallback key');
    }
    
    try {
      // Derive shared secret and AES key
      const sharedSecret = await this.deriveSharedSecret(this.staticPrivateKey, recipientPublicKey);
      const aesKey = await this.deriveAESKey(sharedSecret);
      
      // Encrypt the message
      const encoder = new TextEncoder();
      const data = encoder.encode(plaintext);
      const iv = crypto.getRandomValues(new Uint8Array(12));
      
      const encrypted = await crypto.subtle.encrypt(
        { name: this.aesAlgorithm, iv: iv },
        aesKey,
        data
      );
      
      // Combine IV and encrypted data
      const combined = new Uint8Array(iv.length + encrypted.byteLength);
      combined.set(iv);
      combined.set(new Uint8Array(encrypted), iv.length);
      
      // Get my public key to attach
      const myPublicKeyBase64 = await this.exportPublicKey(this.staticPublicKey);
      const myKeyId = this.generateKeyId(myPublicKeyBase64);
      
      const result = {
        encrypted: btoa(String.fromCharCode(...combined)),
        senderPublicKey: myPublicKeyBase64,
        keyId: myKeyId,
        keyUsed: keyUsed
      };
      
      console.log('🔐 [EC] ✅ ENCRYPTION SUCCESS!');
      console.log('🔐 [EC] 🔑 Key strategy:', keyUsed);
      console.log('🔐 [EC] 🆔 My Key ID:', myKeyId);
      console.log('🔐 [EC] 📦 Encrypted length:', result.encrypted.length);
      
      return result;
      
    } catch (error) {
      console.error('🔐 [EC] ❌ ENCRYPTION FAILED:', error);
      throw error;
    }
  }

  async decrypt(encryptedBase64, senderPublicKeyBase64, senderUserId = null) {
    console.log('🔐 [EC] 📨 DECRYPTING MESSAGE...');
    console.log('🔐 [EC] 📦 Encrypted data length:', encryptedBase64.length);
    console.log('🔐 [EC] 👤 Sender:', senderUserId || 'unknown');
    
    try {
      // Import sender's public key
      const senderPublicKey = await this.importPublicKey(senderPublicKeyBase64);
      const senderKeyId = this.generateKeyId(senderPublicKeyBase64);
      console.log('🔐 [EC] 🔑 Sender Key ID:', senderKeyId);
      
      // Try decryption with my static private key
      const result = await this.tryDecryptWithKey(encryptedBase64, this.staticPrivateKey, senderPublicKey);
      
      if (result) {
        console.log('🔐 [EC] ✅ DECRYPTION SUCCESS!');
        console.log('🔐 [EC] 📝 Decrypted:', result);
        
        // Store sender's public key if we have their user ID
        if (senderUserId) {
          const existing = this.userKeys.get(senderUserId);
          if (!existing || existing.keyId !== senderKeyId) {
            // New or updated key for this user
            this.addUserKey(senderUserId, senderPublicKeyBase64, existing?.username || 'Unknown');
          } else {
            // Update last seen time
            existing.lastSeen = Date.now();
            this.userKeys.set(senderUserId, existing);
            this.saveUserKeys();
          }
        }
        
        return result;
      } else {
        throw new Error('Unable to decrypt with available keys');
      }
      
    } catch (error) {
      console.error('🔐 [EC] ❌ DECRYPTION FAILED:', error);
      throw error;
    }
  }

  async tryDecryptWithKey(encryptedBase64, privateKey, senderPublicKey) {
    try {
      // Decode encrypted data
      const combined = new Uint8Array(
        atob(encryptedBase64).split('').map(char => char.charCodeAt(0))
      );
      
      // Extract IV and encrypted data
      const iv = combined.slice(0, 12);
      const encryptedData = combined.slice(12);
      
      // Derive shared secret and AES key
      const sharedSecret = await this.deriveSharedSecret(privateKey, senderPublicKey);
      const aesKey = await this.deriveAESKey(sharedSecret);
      
      // Decrypt
      const decrypted = await crypto.subtle.decrypt(
        { name: this.aesAlgorithm, iv: iv },
        aesKey,
        encryptedData
      );
      
      const decoder = new TextDecoder();
      return decoder.decode(decrypted);
      
    } catch (error) {
      console.log('🔐 [EC] 🔓 Decryption attempt failed:', error.message);
      return null;
    }
  }

  // ==================== UTILITY METHODS ====================

  async deriveSharedSecret(privateKey, publicKey) {
    return await crypto.subtle.deriveKey(
      { name: this.algorithm, public: publicKey },
      privateKey,
      { name: this.aesAlgorithm, length: 256 },
      false,
      ['encrypt', 'decrypt']
    );
  }

  async deriveAESKey(sharedSecret) {
    return sharedSecret; // The derived key IS the AES key
  }

  generateKeyId(publicKeyBase64) {
    // Simple hash of public key for identification
    return btoa(publicKeyBase64.substring(0, 16)).substring(0, 12);
  }

  async exportPublicKey(publicKey) {
    const exported = await crypto.subtle.exportKey('spki', publicKey);
    return btoa(String.fromCharCode(...new Uint8Array(exported)));
  }

  async exportPrivateKey(privateKey) {
    const exported = await crypto.subtle.exportKey('pkcs8', privateKey);
    return btoa(String.fromCharCode(...new Uint8Array(exported)));
  }

  async importPublicKey(base64Key) {
    const keyData = new Uint8Array(
      atob(base64Key).split('').map(char => char.charCodeAt(0))
    );
    
    return await crypto.subtle.importKey(
      'spki',
      keyData,
      { name: this.algorithm, namedCurve: this.curve },
      true,
      []
    );
  }

  async importPrivateKey(base64Key) {
    const keyData = new Uint8Array(
      atob(base64Key).split('').map(char => char.charCodeAt(0))
    );
    
    return await crypto.subtle.importKey(
      'pkcs8',
      keyData,
      { name: this.algorithm, namedCurve: this.curve },
      true,
      ['deriveKey']
    );
  }

  // ==================== STATUS METHODS ====================

  getStatus() {
    return {
      enabled: true,
      userCount: this.userKeys.size,
      myKeyId: this.staticPublicKey ? this.generateKeyId('temp') : null
    };
  }

  getUserList() {
    return Array.from(this.userKeys.entries()).map(([userId, userInfo]) => ({
      userId,
      username: userInfo.username,
      keyId: userInfo.keyId,
      lastSeen: userInfo.lastSeen,
      discoveredAt: userInfo.discoveredAt
    }));
  }

  async clearAllUsers() {
    this.userKeys.clear();
    await this.saveUserKeys();
    console.log('🔐 [EC] 🗑️ Cleared all user keys');
  }
}

// Export for use by other modules
window.ecCrypto = new ECCrypto();